<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'ghJbGw29SOTeRErTdbkA');
    define('CONSUMER_SECRET', '3Qm3ffztB7yRocStW9qIZEgCiWTGOwkf8pDtq0Fl0');

    // User Access Token
    define('ACCESS_TOKEN', '1369585525-pxJQkwMvkAKrSHfYmZShAX4CF7X5gX2oLQl1hAF');
    define('ACCESS_SECRET', 'fLKNfxy4xEPJTSPEM4Xn98tK8BXMd9YhoZF5C8lNU');